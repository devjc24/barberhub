<template>
  <AdminLayout>
    <PageBreadcrumb pageTitle="Agenda" />
    <div class="p-6 space-y-3">
      <h1 class="text-2xl font-semibold">Agenda</h1>
      <p class="text-sm text-gray-500 dark:text-gray-400">
        Visão da agenda de agendamentos. Tela placeholder.
      </p>
    </div>
  </AdminLayout>
</template>

<script setup lang="ts">
import AdminLayout from '@/components/layout/AdminLayout.vue';
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue';
</script>
