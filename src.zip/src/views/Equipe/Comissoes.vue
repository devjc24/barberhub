<template>
  <AdminLayout>
    <PageBreadcrumb pageTitle="Comissões" />
    <div class="p-6 space-y-3">
      <h1 class="text-2xl font-semibold">Comissões</h1>
      <p class="text-sm text-gray-500 dark:text-gray-400">
        Cálculo e acompanhamento de comissões. Tela placeholder.
      </p>
    </div>
  </AdminLayout>
</template>

<script setup lang="ts">
import AdminLayout from '@/components/layout/AdminLayout.vue';
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue';
</script>
