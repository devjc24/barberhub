<template>
  <AdminLayout>
    <PageBreadcrumb pageTitle="Vendas em Aberto" />
    <div class="p-6 space-y-3">
      <h1 class="text-2xl font-semibold">Vendas em Aberto</h1>
      <p class="text-sm text-gray-500 dark:text-gray-400">
        Listagem de vendas em aberto. Tela placeholder.
      </p>
    </div>
  </AdminLayout>
</template>

<script setup lang="ts">
import AdminLayout from '@/components/layout/AdminLayout.vue';
import PageBreadcrumb from '@/components/common/PageBreadcrumb.vue';
</script>
