// Carrega variáveis de ambiente e centraliza configurações sensíveis
// Pode ser expandido no futuro para usar dotenv.

export const JWT_SECRET = process.env.JWT_SECRET || 'chave_secreta_super_segura';
export const ACCESS_TOKEN_EXPIRES_IN = process.env.ACCESS_TOKEN_EXPIRES_IN || '15m';
export const REFRESH_TOKEN_IDLE_MINUTES =
  Number(process.env.REFRESH_TOKEN_IDLE_MINUTES || 30);
export const REFRESH_TOKEN_IDLE_MINUTES_PERSISTENT =
  Number(process.env.REFRESH_TOKEN_IDLE_MINUTES_PERSISTENT || 60 * 24 * 7);
